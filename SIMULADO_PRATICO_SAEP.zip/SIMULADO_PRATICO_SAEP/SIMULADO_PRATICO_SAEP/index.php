<?php
// --- Bloco de Verificação de Sessão (Controle de Acesso) ---

// Inicia ou resume uma sessão PHP existente.
// Isso é crucial para acessar as variáveis de sessão ($_SESSION).
session_start();

// Verifica se a variável de sessão 'usuario' NÃO está definida (ou seja, o usuário não está logado).
if (!isset($_SESSION['usuario'])) {
    // Se a sessão 'usuario' não existe, redireciona o usuário (força-o) para a página de login.
    header("Location: login.php");
    // Interrompe a execução do script para garantir que nada mais seja processado ou exibido.
    exit;
}

// Se o usuário está logado (o código continuou a execução), armazena o nome de usuário
// da sessão em uma variável local para uso mais fácil no HTML.
$usuario = $_SESSION['usuario'];
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel - Serjão Materiais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ----------- VARIÁVEIS E ESTILO GERAL ----------- */
        :root {
            --primary: #2c5aa0;
            --primary-dark: #1e3d72;
            --secondary: #ff6b35;
            --accent: #28a745;
            --light: #f8f9fa;
            --dark: #343a40;
            --gray: #6c757d;
            --border: #dee2e6;
            --shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            --radius: 10px;
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f2f4f7 0%, #e9ecef 100%);
            color: var(--dark);
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: #fff;
            width: 95%;
            max-width: 900px;
            margin: auto;
            padding: 40px;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            text-align: center;
        }

        /* ----------- CABEÇALHO ----------- */
        .header {
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 2px solid var(--border);
        }

        .logo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
            margin-bottom: 15px;
        }

        .logo-icon {
            background: var(--primary);
            color: white;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            box-shadow: var(--shadow);
        }

        h1 {
            color: var(--primary);
            font-size: 2.2rem;
            margin-bottom: 5px;
        }

        h2 {
            color: var(--gray);
            font-weight: 500;
            font-size: 1.2rem;
        }

        .user-info {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-top: 15px;
            padding: 10px 20px;
            background: #f8f9fa;
            border-radius: 30px;
            display: inline-flex;
        }

        .user-info i {
            color: var(--secondary);
        }

        /* ----------- MENU DE NAVEGAÇÃO ----------- */
        .menu {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin: 40px 0;
        }

        .menu-card {
            background: white;
            border-radius: var(--radius);
            padding: 30px 20px;
            box-shadow: var(--shadow);
            transition: var(--transition);
            border: 1px solid var(--border);
            text-decoration: none;
            color: var(--dark);
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
        }

        .menu-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.12);
            border-color: var(--primary);
        }

        .menu-icon {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            color: white;
            transition: var(--transition);
        }

        .menu-card:nth-child(1) .menu-icon {
            background: linear-gradient(135deg, #2c5aa0, #3a6bc2);
        }

        .menu-card:nth-child(2) .menu-icon {
            background: linear-gradient(135deg, #ff6b35, #ff8c42);
        }

        .menu-card:nth-child(3) .menu-icon {
            background: linear-gradient(135deg, #dc3545, #e95c6a);
        }

        .menu-card:hover .menu-icon {
            transform: scale(1.1);
        }

        .menu-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: var(--primary);
        }

        .menu-description {
            color: var(--gray);
            font-size: 0.9rem;
            text-align: center;
            line-height: 1.5;
        }

        /* ----------- BOTÃO SAIR ----------- */
        .logout-container {
            margin-top: 40px;
            padding-top: 30px;
            border-top: 1px solid var(--border);
        }

        .btn-logout {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 12px 30px;
            background: transparent;
            color: var(--gray);
            border: 1px solid var(--border);
            border-radius: 30px;
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
        }

        .btn-logout:hover {
            background: #f8f9fa;
            color: var(--dark);
            border-color: var(--gray);
        }

        /* ----------- RODAPÉ ----------- */
        .footer {
            margin-top: 40px;
            color: var(--gray);
            font-size: 0.9rem;
        }

        /* ----------- RESPONSIVIDADE ----------- */
        @media (max-width: 768px) {
            .container {
                padding: 30px 20px;
            }
            
            h1 {
                font-size: 1.8rem;
            }
            
            .menu {
                grid-template-columns: 1fr;
            }
            
            .logo {
                flex-direction: column;
                text-align: center;
            }
        }

        /* ----------- ANIMAÇÃO ----------- */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .container {
            animation: fadeIn 0.5s ease;
        }

        .menu-card {
            animation: fadeIn 0.5s ease;
        }

        .menu-card:nth-child(1) { animation-delay: 0.1s; }
        .menu-card:nth-child(2) { animation-delay: 0.2s; }
        .menu-card:nth-child(3) { animation-delay: 0.3s; }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">
            <div class="logo">
                <div class="logo-icon">
                    <i class="fas fa-warehouse"></i>
                </div>
                <div>
                    <h1>Serjão Materiais</h1>
                    <h2>Sistema de Gestão</h2>
                </div>
            </div>
            
            <div class="user-info">
                <i class="fas fa-user-circle"></i>
                <span>Bem-vindo, <strong><?php echo htmlspecialchars($usuario); ?></strong>!</span>
            </div>
        </div>

        <nav class="menu">
            <a href="cadastro_produto.php" class="menu-card">
                <div class="menu-icon">
                    <i class="fas fa-boxes"></i>
                </div>
                <div class="menu-title">Cadastro de Produtos</div>
                <div class="menu-description">
                    Adicione, edite ou remova produtos do catálogo
                </div>
            </a>
            
            <a href="estoque.php" class="menu-card">
                <div class="menu-icon">
                    <i class="fas fa-chart-bar"></i>
                </div>
                <div class="menu-title">Gestão de Estoque</div>
                <div class="menu-description">
                    Controle de entradas, saídas e movimentações
                </div>
            </a>
            
            <a href="logout.php" class="menu-card">
                <div class="menu-icon">
                    <i class="fas fa-sign-out-alt"></i>
                </div>
                <div class="menu-title">Sair do Sistema</div>
                <div class="menu-description">
                    Encerrar sessão e voltar à tela de login
                </div>
            </a>
        </nav>

        <div class="logout-container">
            <a href="logout.php" class="btn-logout">
                <i class="fas fa-sign-out-alt"></i>
                Sair do Sistema
            </a>
        </div>

        <div class="footer">
            <p>Serjão Materiais &copy; 2023 - Todos os direitos reservados</p>
        </div>
    </div>

    <script>
        // Adicionar efeito de confirmação ao sair
        document.addEventListener('DOMContentLoaded', function() {
            const logoutLinks = document.querySelectorAll('a[href="logout.php"]');
            
            logoutLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    if (!confirm('Tem certeza que deseja sair do sistema?')) {
                        e.preventDefault();
                    }
                });
            });
            
            // Adicionar data atual no rodapé
            const year = new Date().getFullYear();
            const footer = document.querySelector('.footer p');
            footer.innerHTML = `Serjão Materiais &copy; ${year} - Todos os direitos reservados`;
        });
    </script>
</body>
</html>
