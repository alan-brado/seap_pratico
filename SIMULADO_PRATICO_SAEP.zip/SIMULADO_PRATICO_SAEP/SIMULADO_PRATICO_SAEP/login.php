<?php
// --- Bloco de Processamento de Login ---

// 1. Inicia ou retoma uma sessão PHP existente.
// É essencial para poder armazenar dados do usuário após o login (como nome e ID).
session_start();

// 2. Inclui o arquivo de conexão com o banco de dados.
// Isso torna a variável $conn (objeto de conexão) disponível neste script.
include('conexao.php');

// 3. Verifica se o formulário de login foi submetido.
// A verificação é feita checando se o campo 'email' (enviado via método POST) está definido.
if (isset($_POST['email'])) {
    
    // 4. Captura e sanitiza os dados de entrada.
    // Captura o email digitado pelo usuário.
    $email = $_POST['email'];
    
    // Captura a senha digitada e a criptografa usando o algoritmo MD5.
    // ATENÇÃO: Embora funcione, MD5 é um algoritmo de hash fraco e não recomendado para senhas em produção.
    $senha = md5($_POST['senha']);

    // 5. Constrói a consulta SQL para verificar as credenciais.
    // Seleciona todos os campos de um usuário onde o 'email' e a 'senha' (já criptografada) coincidem.
    $sql = "SELECT * FROM usuarios WHERE email='$email' AND senha='$senha'";
    
    // 6. Executa a consulta SQL no banco de dados.
    // $conn é o objeto de conexão vindo de 'conexao.php'.
    $result = $conn->query($sql);

    // 7. Avalia o resultado da consulta.
    // 'num_rows' retorna o número de linhas encontradas. Se for 1, as credenciais estão corretas.
    if ($result->num_rows == 1) {
        
        // Se a busca retornar 1 linha: Login bem-sucedido.
        
        // Pega todos os dados da linha encontrada no banco de dados como um array associativo.
        $user = $result->fetch_assoc();
        
        // Cria variáveis de sessão para manter o usuário logado e identificado.
        $_SESSION['usuario'] = $user['nome'];           // Armazena o nome do usuário para exibição (ex: no index.php).
        $_SESSION['id_usuario'] = $user['id_usuario'];  // Armazena o ID do usuário para uso em outras operações (cadastro/estoque).
        
        // Redireciona o usuário para a página principal (Painel).
        header("Location: index.php");
        
        // Encerra o script para evitar processamento desnecessário após o redirecionamento.
        exit;
    } else {
        // Se a busca retornar 0 linhas: Login falhou.
        // Define uma mensagem de erro que será exibida no HTML.
        $erro = "Usuário ou senha incorretos.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Serjão Materiais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ----------- VARIÁVEIS E ESTILO GERAL ----------- */
        :root {
            --primary: #2c5aa0;
            --primary-dark: #1e3d72;
            --secondary: #ff6b35;
            --accent: #28a745;
            --light: #f8f9fa;
            --dark: #343a40;
            --gray: #6c757d;
            --border: #dee2e6;
            --shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            --radius: 10px;
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #1e3d72 0%, #2c5aa0 50%, #3a6bc2 100%);
            color: var(--dark);
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .container {
            background: #fff;
            width: 95%;
            max-width: 450px;
            margin: auto;
            padding: 40px 35px;
            border-radius: var(--radius);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        /* ----------- LOGO E CABEÇALHO ----------- */
        .logo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
            margin-bottom: 30px;
        }

        .logo-icon {
            background: var(--primary);
            color: white;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            box-shadow: var(--shadow);
        }

        h2 {
            color: var(--primary);
            font-size: 1.8rem;
            margin-bottom: 5px;
        }

        .subtitle {
            color: var(--gray);
            font-size: 1rem;
            margin-bottom: 30px;
        }

        /* ----------- FORMULÁRIO ----------- */
        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--dark);
        }

        .input-with-icon {
            position: relative;
        }

        .input-with-icon i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
            font-size: 18px;
        }

        input {
            width: 100%;
            padding: 15px 15px 15px 50px;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            font-size: 16px;
            transition: var(--transition);
        }

        input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(44, 90, 160, 0.2);
        }

        /* ----------- BOTÃO ----------- */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: var(--radius);
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            text-decoration: none;
            margin-top: 10px;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            box-shadow: 0 4px 10px rgba(44, 90, 160, 0.3);
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(44, 90, 160, 0.4);
        }

        .btn-primary:active {
            transform: translateY(0);
        }

        /* ----------- MENSAGEM DE ERRO ----------- */
        .erro {
            background-color: #ffebee;
            color: #c62828;
            padding: 15px;
            border-radius: var(--radius);
            margin: 20px 0;
            border-left: 4px solid #f44336;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            animation: shake 0.5s ease;
        }

        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }

        /* ----------- LINKS ADICIONAIS ----------- */
        .links {
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            font-size: 0.9rem;
        }

        .links a {
            color: var(--primary);
            text-decoration: none;
            transition: var(--transition);
        }

        .links a:hover {
            color: var(--primary-dark);
            text-decoration: underline;
        }

        /* ----------- RODAPÉ ----------- */
        .footer {
            margin-top: 30px;
            color: var(--gray);
            font-size: 0.85rem;
        }

        /* ----------- RESPONSIVIDADE ----------- */
        @media (max-width: 480px) {
            .container {
                padding: 30px 20px;
            }
            
            h2 {
                font-size: 1.5rem;
            }
            
            .logo {
                flex-direction: column;
                text-align: center;
            }
            
            .links {
                flex-direction: column;
                gap: 10px;
                text-align: center;
            }
        }

        /* ----------- ANIMAÇÃO ----------- */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .container {
            animation: fadeIn 0.6s ease;
        }

        /* ----------- DECORAÇÃO ----------- */
        .decoration {
            position: absolute;
            width: 200px;
            height: 200px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            z-index: -1;
        }

        .decoration-1 {
            top: 10%;
            left: 10%;
            width: 150px;
            height: 150px;
        }

        .decoration-2 {
            bottom: 10%;
            right: 10%;
            width: 100px;
            height: 100px;
        }
    </style>
</head>
<body>
    <div class="decoration decoration-1"></div>
    <div class="decoration decoration-2"></div>
    
    <div class="container">
        <div class="logo">
            <div class="logo-icon">
                <i class="fas fa-warehouse"></i>
            </div>
            <div>
                <h2>Serjão Materiais</h2>
                <div class="subtitle">Sistema de Gestão</div>
            </div>
        </div>

        <form method="post">
            <div class="form-group">
                <label for="email">E-mail</label>
                <div class="input-with-icon">
                    <i class="fas fa-envelope"></i>
                    <input type="email" id="email" name="email" placeholder="seu@email.com" required>
                </div>
            </div>

            <div class="form-group">
                <label for="senha">Senha</label>
                <div class="input-with-icon">
                    <i class="fas fa-lock"></i>
                    <input type="password" id="senha" name="senha" placeholder="Sua senha" required>
                </div>
            </div>

            <button type="submit" class="btn btn-primary">
                <i class="fas fa-sign-in-alt"></i>
                Entrar no Sistema
            </button>
        </form>

        <?php if (isset($erro)): ?>
            <div class="erro">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo $erro; ?>
            </div>
        <?php endif; ?>

        <div class="links">
            <a href="#">
                <i class="fas fa-question-circle"></i>
                Esqueci minha senha
            </a>
            <a href="#">
                <i class="fas fa-user-plus"></i>
                Criar conta
            </a>
        </div>

        <div class="footer">
            <p>Serjão Materiais &copy; 2023 - Todos os direitos reservados</p>
        </div>
    </div>

    <script>
        // Adicionar interatividade aos campos
        document.addEventListener('DOMContentLoaded', function() {
            const inputs = document.querySelectorAll('input');
            
            inputs.forEach(input => {
                // Adicionar foco automático no primeiro campo
                if (input.type === 'email') {
                    input.focus();
                }
                
                // Adicionar validação visual
                input.addEventListener('blur', function() {
                    if (this.value.trim() !== '') {
                        this.style.borderColor = '#28a745';
                    } else {
                        this.style.borderColor = '#dee2e6';
                    }
                });
            });
            
            // Adicionar data atual no rodapé
            const year = new Date().getFullYear();
            const footer = document.querySelector('.footer p');
            footer.innerHTML = `Serjão Materiais &copy; ${year} - Todos os direitos reservados`;
            
            // Efeito de digitação no subtítulo
            const subtitle = document.querySelector('.subtitle');
            const originalText = subtitle.textContent;
            subtitle.textContent = '';
            let i = 0;
            
            function typeWriter() {
                if (i < originalText.length) {
                    subtitle.textContent += originalText.charAt(i);
                    i++;
                    setTimeout(typeWriter, 50);
                }
            }
            
            // Iniciar efeito de digitação após um breve delay
            setTimeout(typeWriter, 800);
        });
    </script>
</body>
</html>