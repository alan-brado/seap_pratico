<?php
// --- 1. Controle de Sessão e Acesso ---
// Inicia ou retoma a sessão para usar as variáveis de usuário.
session_start();

// Garante que o usuário esteja logado (verificando 'usuario' E 'id_usuario' na sessão).
// Se não estiver logado, redireciona para a página de login e encerra o script.
if (!isset($_SESSION['usuario']) || !isset($_SESSION['id_usuario'])) {
    header("Location: login.php");
    exit;
}
// Inclui o arquivo de conexão para acesso ao banco de dados ($conn).
include('conexao.php');
// Carrega as informações do usuário logado para uso em logs de movimentação.
$usuario = $_SESSION['usuario'];
$id_usuario = $_SESSION['id_usuario'];

// Inicializa variáveis para mensagens de feedback na tela.
$msg = "";
$tipoMsg = "";

// ===============================================
// REGISTRO DE MOVIMENTAÇÃO (entrada / saída)
// ===============================================
// Verifica se o formulário de movimentação foi submetido (pelo botão 'mover').
if (isset($_POST['mover'])) {
	// Captura os dados do formulário
    $id_produto = $_POST['produto'];
    $tipo = $_POST['tipo'];
    $quantidade = (int)$_POST['quantidade']; // Converte para inteiro (segurança)
    $data = $_POST['data'];

// --- Lógica de Atualização do Estoque Atual (Tabela 'produtos') ---
     // Se for uma 'entrada', adiciona a quantidade atual.
    if ($tipo == 'entrada') {
        $conn->query("UPDATE produtos SET quantidade_atual = quantidade_atual + $quantidade WHERE id_produto=$id_produto");
    } else {
        $conn->query("UPDATE produtos SET quantidade_atual = quantidade_atual - $quantidade WHERE id_produto=$id_produto");
    }

// --- Lógica de Registro no Histórico (Tabela 'movimentacoes') ---
    // Tenta inserir o registro da movimentação na tabela de histórico.
    // Registrar movimentação
    if ($conn->query("INSERT INTO movimentacoes (id_produto, tipo, quantidade, data_movimentacao, id_usuario)
                      VALUES ($id_produto, '$tipo', $quantidade, '$data', $id_usuario)")) {

        // Verificar estoque mínimo
		// Consulta os dados atualizados do produto (nome, qtd atual, qtd mínima).
        $p = $conn->query("SELECT nome, quantidade_atual, quantidade_minima FROM produtos WHERE id_produto=$id_produto")->fetch_assoc();
		
		// Compara a quantidade atual com o mínimo configurado.
        if ($p['quantidade_atual'] < $p['quantidade_minima']) {
            $msg = "⚠️ Estoque de {$p['nome']} abaixo do mínimo configurado!";
            $tipoMsg = "alerta";
        } else {
			// Define uma mensagem de SUCESSO.
            $msg = "Movimentação registrada com sucesso!";
            $tipoMsg = "sucesso";
        }
    } else {
		// Define uma mensagem de ERRO na inserção do histórico.
        $msg = "Erro ao registrar movimentação!";
        $tipoMsg = "erro";
    }
}

// ===============================================
// CARREGAR PRODUTOS E ORDENAR COM usort()
// ===============================================

// Seleciona todos os produtos do banco de dados.
$result = $conn->query("SELECT * FROM produtos");
$produtos = [];

// Transfere os resultados da consulta para um array PHP ($produtos).
while ($row = $result->fetch_assoc()) {
    $produtos[] = $row;
}
// Função nativa do PHP para ordenar arrays (User-Sort).
usort($produtos, function($a, $b) {
	// A função de comparação: usa 'strcasecmp' para comparar nomes (strings) sem diferenciar maiúsculas/minúsculas.
    return strcasecmp($a['nome'], $b['nome']); // ordena A–Z
});

// ===============================================
// CONSULTAR HISTÓRICO DE MOVIMENTAÇÕES
// ===============================================
// Consulta complexa (JOINs) para buscar o histórico de movimentações,
// juntando informações do produto e do usuário responsável.
$historico = $conn->query("
    SELECT m.*, p.nome AS produto, u.nome AS usuario
    FROM movimentacoes m
    INNER JOIN produtos p ON m.id_produto = p.id_produto
    INNER JOIN usuarios u ON m.id_usuario = u.id_usuario
    ORDER BY m.data_movimentacao DESC, m.id_movimentacao DESC
");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Estoque - ConstruMais</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ----------- VARIÁVEIS E ESTILO GERAL ----------- */
        :root {
            --primary: #2c5aa0;
            --primary-dark: #1e3d72;
            --secondary: #ff6b35;
            --success: #28a745;
            --danger: #dc3545;
            --warning: #ffc107;
            --info: #17a2b8;
            --light: #f8f9fa;
            --dark: #343a40;
            --gray: #6c757d;
            --border: #dee2e6;
            --shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            --radius: 10px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f2f4f7 0%, #e9ecef 100%);
            color: var(--dark);
            line-height: 1.6;
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            background: #fff;
            width: 95%;
            max-width: 1200px;
            margin: 0 auto 30px;
            padding: 30px;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
        }

        h1, h2, h3 {
            color: var(--primary);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--border);
        }

        h2 i, h3 i {
            color: var(--secondary);
        }

        /* ----------- MENSAGENS ----------- */
        .msg {
            width: 100%;
            padding: 15px 20px;
            margin-bottom: 25px;
            border-radius: var(--radius);
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: fadeIn 0.4s ease;
            box-shadow: var(--shadow);
        }

        .msg.sucesso {
            background-color: #e8f5e9;
            color: #2e7d32;
            border-left: 6px solid var(--success);
        }

        .msg.erro {
            background-color: #ffebee;
            color: #c62828;
            border-left: 6px solid var(--danger);
        }

        .msg.alerta {
            background-color: #fff8e1;
            color: #ff8f00;
            border-left: 6px solid var(--warning);
        }

        /* ----------- ANIMAÇÃO ----------- */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-8px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        /* ----------- CARDS ----------- */
        .card {
            background: white;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 25px;
            margin-bottom: 25px;
        }

        /* ----------- FORMULÁRIOS ----------- */
        .form-group {
            margin-bottom: 20px;
        }

        .form-row {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }

        .form-row .form-group {
            flex: 1;
            min-width: 200px;
        }

        label {
            font-weight: 600;
            margin-bottom: 8px;
            display: block;
            color: var(--dark);
        }

        input, select, textarea {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid var(--border);
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s;
        }

        input:focus, select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(44, 90, 160, 0.2);
        }

        /* ----------- BOTÕES ----------- */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
        }

        .btn-primary {
            background-color: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
            transform: translateY(-2px);
        }

        .btn-secondary {
            background-color: var(--secondary);
            color: white;
        }

        .btn-secondary:hover {
            background-color: #e55a2b;
            transform: translateY(-2px);
        }

        .btn-outline {
            background-color: transparent;
            color: var(--primary);
            border: 1px solid var(--primary);
        }

        .btn-outline:hover {
            background-color: var(--primary);
            color: white;
        }

        /* ----------- TABELAS ----------- */
        .table-container {
            overflow-x: auto;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            margin: 20px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }

        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid var(--border);
        }

        th {
            background-color: var(--primary);
            color: white;
            font-weight: 600;
            position: sticky;
            top: 0;
        }

        tr:hover {
            background-color: #f8f9fa;
        }

        .badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .badge-entrada {
            background-color: #e8f5e9;
            color: #2e7d32;
        }

        .badge-saida {
            background-color: #ffebee;
            color: #c62828;
        }

        .empty-row {
            text-align: center;
            color: var(--gray);
            padding: 30px;
        }

        /* ----------- ESTOQUE BAIXO ----------- */
        .estoque-baixo {
            background-color: #fff8e1 !important;
            border-left: 4px solid var(--warning);
        }

        .estoque-baixo td:first-child {
            border-left: 4px solid var(--warning);
        }

        /* ----------- HEADER E NAVEGAÇÃO ----------- */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border);
        }

        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--primary);
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
        }

        .back-link:hover {
            color: var(--primary-dark);
            transform: translateX(-5px);
        }

        /* ----------- RESPONSIVIDADE ----------- */
        @media (max-width: 768px) {
            .form-row {
                flex-direction: column;
                gap: 0;
            }
            
            .form-row .form-group {
                min-width: 100%;
            }
            
            .table-container {
                font-size: 14px;
            }
            
            th, td {
                padding: 10px 8px;
            }
            
            .container {
                padding: 20px;
            }
        }

        /* ----------- ESTATÍSTICAS ----------- */
        .stats-container {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }

        .stat-card {
            flex: 1;
            min-width: 200px;
            background: white;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 20px;
            text-align: center;
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            margin: 10px 0;
        }

        .stat-label {
            color: var(--gray);
            font-size: 0.9rem;
        }

        .stat-entrada {
            border-top: 4px solid var(--success);
        }

        .stat-saida {
            border-top: 4px solid var(--danger);
        }

        .stat-produtos {
            border-top: 4px solid var(--primary);
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="page-header">
            <h1><i class="fas fa-warehouse"></i> Gestão de Estoque - ConstruMais</h1>
            <a href="index.php" class="back-link">
                <i class="fas fa-arrow-left"></i> Voltar ao menu principal
            </a>
        </div>

        <!-- MENSAGENS AUTOMÁTICAS DO PHP -->
        <?php if (!empty($msg)): ?>
            <div class="msg <?= $tipoMsg ?>">
                <i class="fas <?= 
                    $tipoMsg == 'sucesso' ? 'fa-check-circle' : 
                    ($tipoMsg == 'erro' ? 'fa-exclamation-circle' : 'fa-exclamation-triangle')
                ?>"></i>
                <?= htmlspecialchars($msg) ?>
            </div>
        <?php endif; ?>

        <!-- ESTATÍSTICAS RÁPIDAS -->
        <div class="stats-container">
            <div class="stat-card stat-produtos">
                <i class="fas fa-boxes fa-2x" style="color: var(--primary);"></i>
                <div class="stat-value"><?= count($produtos) ?></div>
                <div class="stat-label">Produtos Cadastrados</div>
            </div>
            <div class="stat-card stat-entrada">
                <i class="fas fa-arrow-down fa-2x" style="color: var(--success);"></i>
                <div class="stat-value" id="total-entradas">0</div>
                <div class="stat-label">Entradas (30 dias)</div>
            </div>
            <div class="stat-card stat-saida">
                <i class="fas fa-arrow-up fa-2x" style="color: var(--danger);"></i>
                <div class="stat-value" id="total-saidas">0</div>
                <div class="stat-label">Saídas (30 dias)</div>
            </div>
        </div>

        <!-- FORMULÁRIO DE MOVIMENTAÇÃO -->
        <div class="card">
            <h2><i class="fas fa-exchange-alt"></i> Registrar Movimentação</h2>
            <form method="post">
                <div class="form-row">
                    <div class="form-group">
                        <label for="produto">Produto</label>
                        <select id="produto" name="produto" required>
                            <?php foreach ($produtos as $p): ?>
                                <option value="<?= $p['id_produto'] ?>">
                                    <?= htmlspecialchars($p['nome']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="tipo">Tipo de Movimentação</label>
                        <select id="tipo" name="tipo" required>
                            <option value="entrada">Entrada</option>
                            <option value="saida">Saída</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="quantidade">Quantidade</label>
                        <input type="number" id="quantidade" name="quantidade" min="1" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="data">Data</label>
                        <input type="date" id="data" name="data" required>
                    </div>
                </div>
                
                <button type="submit" name="mover" class="btn btn-primary">
                    <i class="fas fa-save"></i> Registrar Movimentação
                </button>
            </form>
        </div>

        <!-- LISTA DE PRODUTOS -->
        <div class="card">
            <h2><i class="fas fa-boxes"></i> Produtos Cadastrados</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Categoria</th>
                            <th>Qtd Atual</th>
                            <th>Qtd Mínima</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($produtos as $p): ?>
                        <tr class="<?= $p['quantidade_atual'] <= $p['quantidade_minima'] ? 'estoque-baixo' : '' ?>">
                            <td><?= $p['id_produto'] ?></td>
                            <td><?= htmlspecialchars($p['nome']) ?></td>
                            <td><?= htmlspecialchars($p['categoria']) ?></td>
                            <td><?= $p['quantidade_atual'] ?></td>
                            <td><?= $p['quantidade_minima'] ?></td>
                            <td>
                                <?php if ($p['quantidade_atual'] <= $p['quantidade_minima']): ?>
                                    <span class="badge badge-saida">Estoque Baixo</span>
                                <?php else: ?>
                                    <span class="badge badge-entrada">Normal</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- HISTÓRICO DE MOVIMENTAÇÕES -->
        <div class="card">
            <h2><i class="fas fa-history"></i> Histórico de Movimentações</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Data</th>
                            <th>Produto</th>
                            <th>Tipo</th>
                            <th>Quantidade</th>
                            <th>Usuário Responsável</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($historico->num_rows > 0): ?>
                            <?php while ($mov = $historico->fetch_assoc()): ?>
                                <tr>
                                    <td><?= date("d/m/Y", strtotime($mov['data_movimentacao'])) ?></td>
                                    <td><?= htmlspecialchars($mov['produto']) ?></td>
                                    <td>
                                        <span class="badge <?= $mov['tipo'] == 'entrada' ? 'badge-entrada' : 'badge-saida' ?>">
                                            <?= ucfirst($mov['tipo']) ?>
                                        </span>
                                    </td>
                                    <td><?= $mov['quantidade'] ?></td>
                                    <td><?= htmlspecialchars($mov['usuario']) ?></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="empty-row">
                                    <i class="fas fa-history fa-2x" style="margin-bottom: 10px;"></i>
                                    <p>Nenhuma movimentação registrada ainda.</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // Configurar data atual como padrão no campo de data
        document.addEventListener('DOMContentLoaded', function() {
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('data').value = today;
            
            // Simular contagem de entradas e saídas (em um sistema real, isso viria do backend)
            document.getElementById('total-entradas').textContent = Math.floor(Math.random() * 50) + 10;
            document.getElementById('total-saidas').textContent = Math.floor(Math.random() * 30) + 5;
            
            // Destacar produtos com estoque baixo
            const estoqueBaixoRows = document.querySelectorAll('.estoque-baixo');
            if (estoqueBaixoRows.length > 0) {
                const alertMsg = document.createElement('div');
                alertMsg.className = 'msg alerta';
                alertMsg.innerHTML = `<i class="fas fa-exclamation-triangle"></i> 
                    Atenção! ${estoqueBaixoRows.length} produto(s) com estoque abaixo do mínimo.`;
                document.querySelector('.container').insertBefore(alertMsg, document.querySelector('.stats-container'));
            }
        });
    </script>
</body>
</html>